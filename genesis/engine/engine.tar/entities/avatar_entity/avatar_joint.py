import taichi as ti

from ..rigid_entity import RigidJoint


@ti.data_oriented
class AvatarJoint(RigidJoint):
    pass
